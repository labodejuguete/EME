# EME-sequencer
Polymetric and polyrhythmic sequencer based on Arduino to control motors and lights.
